# STEGANOS — Image Steganography App

> Single HTML file. Zero dependencies. Open and run instantly in any browser.

Hide secret messages inside ordinary images using LSB (Least Significant Bit) steganography with optional XOR encryption.

---

## ▶ How to Run in VSCode

### Option 1 — Live Server (Recommended)
1. Install the **Live Server** extension in VSCode
   - Press `Ctrl+Shift+X` → search "Live Server" → Install
2. Open the `STEGANOS` folder in VSCode
3. Right-click `index.html` → **"Open with Live Server"**
4. Browser opens at `http://127.0.0.1:5500`

### Option 2 — Direct Open (also works)
1. Just double-click `index.html` in your file explorer
2. Or drag it into any browser window
3. The app runs fully offline — no server needed

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| **ENCODE** | Select image → type secret message → optional passkey → download stego PNG |
| **DECODE** | Load stego PNG → enter passkey → extract and copy hidden message |
| **Capacity meter** | Live bar shows how much of the image's pixel space the message uses |
| **XOR encryption** | Optional passkey XOR-encrypts the message before embedding |
| **Drag & drop** | Drop images directly onto the upload zones |
| **Boot sequence** | Animated initialization screen on startup |
| **Copy / Download** | Decoded messages can be copied or saved as .txt |
| **100% offline** | Zero network requests — works after first load with no internet |

---

## 🔬 How LSB Steganography Works

The app modifies the **Least Significant Bit** of each R, G, B channel value:

```
Pixel channel: 11001000 (200)
Changed to:    11001001 (201)  ← stores bit "1"
```

The change is ±1 — completely **invisible to human vision** but perfectly recoverable.

**Capacity formula:**  `max_chars = ⌊(width × height × 3 − 32) ÷ 8⌋`

| Image Size | Max Characters |
|------------|---------------|
| 640×480    | ~115,200      |
| 1280×720   | ~345,600      |
| 1920×1080  | ~777,600      |

---

## ⚠️ Important

- **Always use PNG output** — JPEG recompression destroys LSB data permanently
- **XOR passkeys are case-sensitive** — `MyKey` ≠ `mykey`
- All processing runs **in your browser** — no data ever leaves your machine

---

## 📄 File Structure

```
STEGANOS/
├── index.html    ← The entire app (HTML + CSS + JS in one file)
└── README.md     ← This file
```

That's it. One file.
